package proj_c208;

public class Proj_C208 {
    // Declaração dos registradores ------------------------------------------------------------------------------//
    static Registrador r0 = new Registrador();
    static Registrador r1 = new Registrador();
    static Registrador r2 = new Registrador();
    static Registrador r3 = new Registrador();
    static Registrador r4 = new Registrador();
    static Registrador r5 = new Registrador();
    static Registrador r6 = new Registrador();
    static Registrador r7 = new Registrador();
    //------------------------------------------------------------------------------------------------------------//

    static Registrador RI = new Registrador(); // IR
    static Registrador CI = new Registrador(); // PC
    
    public static void main(String[] args) {
        // Declaração dos registradores ------------------------------------------------------------------------------//
        r0.endereco = "0000";
        r0.valor = 0;
        r1.endereco = "0001";
        r1.valor = 1;
        r2.endereco = "0010";
        r2.valor = 2;
        r3.endereco = "0011";
        r3.valor = 3;
        r4.endereco = "0100";
        r4.valor = 4;
        r5.endereco = "0101";
        r5.valor = 5;
        r6.endereco = "0110";
        r6.valor = 6;
        r7.endereco = "0111";
        r7.valor = 7;
        //------------------------------------------------------------------------------------------------------------//

        // Instruções salvas na memória ------------------------------------------------------------------------------//
        String[] requisicoes = new String[]{"0001001000110111", "0000010000010101", "0010011001010000", "0011011101100100", "0010011001010000"};
        String[] memoria = new String[]{"0001001000110111", "0000010000010101", "0010011001010000", "0011011101100100"
            + "0000010000010101", "0001001000110111", "0011011101100100", "0010011001010000"};
        
        Cache c1 = new Cache();
        Cache c2 = new Cache();
        Cache[] cache = new Cache[]{c1,c2};
        //------------------------------------------------------------------------------------------------------------//

        // Start do programa -----------------------------------------------------------------------------------------//
        start(requisicoes, cache, memoria);
        //------------------------------------------------------------------------------------------------------------//
    }
    
    public static void start(String[] requisicoes, Cache[] cache, String[] memoria) {
        // Start do programa -----------------------------------------------------------------------------------------//
        // PC é inicializado apontando para o endereço inicial da memória (0)
        // e é atualizado para o próximo endereço após o término de cada instrução
        boolean op = true;
        CI.valor = 0;
        
        System.out.println("CI -> 0");
        for (CI.valor = 0; CI.valor < requisicoes.length; CI.valor++) {
            
            //Busca na cache
            for (int j = 0; j < cache.length; j++) {
                if (requisicoes[CI.valor].equals(cache[j].data)) {
                    op = true;
                    System.out.println("");
                    System.out.println("Cache Hit!");
                    interpretacao(cache[j].data);
                    break;
                } else {
                    op = false;
                }
            }

            //Busca na memória principal
            if (op == false) {
                System.out.println("");
                System.out.println("Cache Miss!");
                for (int k = 0; k < memoria.length; k++) {
                    if (requisicoes[CI.valor].equals(memoria[k])) {
                        if (k % 2 == 0) {
                            cache[0].data = memoria[k];
                            cache[0].bitValid = true;
                            cache[0].tag = k;
                        } else {
                            cache[1].data = memoria[k];
                            cache[1].bitValid = true;
                            cache[1].tag = k;
                        }
                        interpretacao(memoria[k]);
                        break;
                    }
                }
            }
            System.out.println("CI -> CI + 1");
        }
    }
    
    public static void interpretacao(String data){
            String auxOp = "";
            String auxRegUm = "";
            String auxRegDois = "";
            String auxRegResp = "";

            for (int i = 0; i < 4; i++) {
                auxOp = auxOp + data.charAt(i);
            }

            for (int i = 4; i < 8; i++) {
                auxRegUm = auxRegUm + data.charAt(i);
            }

            for (int i = 8; i < 12; i++) {
                auxRegDois = auxRegDois + data.charAt(i);
            }

            for (int i = 12; i < 16; i++) {
                auxRegResp = auxRegResp + data.charAt(i);
            }

            Instrucao testeI = new Instrucao();

            testeI.op = auxOp;

            switch (auxRegUm) {
                case "0000":
                    testeI.registradorUM = r0;
                    break;
                case "0001":
                    testeI.registradorUM = r1;
                    break;
                case "0010":
                    testeI.registradorUM = r2;
                    break;
                case "0011":
                    testeI.registradorUM = r3;
                    break;
                case "0100":
                    testeI.registradorUM = r4;
                    break;
                case "0101":
                    testeI.registradorUM = r5;
                    break;
                case "0110":
                    testeI.registradorUM = r6;
                    break;
                case "0111":
                    testeI.registradorUM = r7;
                    break;
                default:
                    break;
            }

            switch (auxRegDois) {
                case "0000":
                    testeI.registradorDois = r0;
                    break;
                case "0001":
                    testeI.registradorDois = r1;
                    break;
                case "0010":
                    testeI.registradorDois = r2;
                    break;
                case "0011":
                    testeI.registradorDois = r3;
                    break;
                case "0100":
                    testeI.registradorDois = r4;
                    break;
                case "0101":
                    testeI.registradorDois = r5;
                    break;
                case "0110":
                    testeI.registradorDois = r6;
                    break;
                case "0111":
                    testeI.registradorDois = r7;
                    break;
                default:
                    break;
            }

            switch (auxRegResp) {
                case "0000":
                    testeI.registradorResposta = r0;
                    break;
                case "0001":
                    testeI.registradorResposta = r1;
                    break;
                case "0010":
                    testeI.registradorResposta = r2;
                    break;
                case "0011":
                    testeI.registradorResposta = r3;
                    break;
                case "0100":
                    testeI.registradorResposta = r4;
                    break;
                case "0101":
                    testeI.registradorResposta = r5;
                    break;
                case "0110":
                    testeI.registradorResposta = r6;
                    break;
                case "0111":
                    testeI.registradorResposta = r7;
                    break;
                default:
                    break;
            }

            System.out.println(auxOp);
            System.out.println(auxRegUm);
            System.out.println(auxRegDois);
            System.out.println(auxRegResp);

            System.out.println("------------------------------------");

            // Formação da instrução ----------------------------------------------------------------------//
            testeI.InstructionFormation();
            //----------------------------------------------------------------------------------------------------------//

            // Execução da instrução -----------------------------------------------------------------------------------//
            RI.dataCI = data;
            testeI.InstructionExecute();
            System.out.println("Valor armazenado no endereço: " + testeI.registradorResposta.endereco);
            System.out.println("Valor: " + testeI.registradorResposta.valor);

            System.out.println("-------------------------------------");
            //----------------------------------------------------------------------------------------------------------//
    }
}
