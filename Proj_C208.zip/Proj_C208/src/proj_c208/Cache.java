/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj_c208;

/**
 *
 * @author Pedro Henrique
 */
public class Cache {
    public boolean bitValid;
    public int tag;
    public String data;

}
