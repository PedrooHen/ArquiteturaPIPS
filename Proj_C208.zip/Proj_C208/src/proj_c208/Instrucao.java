/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj_c208;

/**
 *
 * @author aluno
 */
public class Instrucao {
    public String op;
    public Registrador registradorUM;
    public Registrador registradorDois;
    public Registrador registradorResposta;
    public int operacao = 0; // 1 - Soma (0001) 2 - Subtracao (0010) 3 - Igual (0000) 4 - Maior (0011)
    
    public void InstructionFormation(){
        if (null != op)
            switch (op) {
            case "0000":
                operacao = 3;
                break;
            case "0001":
                operacao = 1;
                break;
            case "0010":
                operacao = 2;
                break;
            case "0011":
                operacao = 4;
                break;
            default:
                break;
        }
    }
    
    public void InstructionExecute(){
        switch(operacao){
            case 1:
                System.out.println("SOMA");
                registradorResposta.valor = registradorUM.valor + registradorDois.valor;
                break;
            case 2:
                System.out.println("SUBTRACAO");
                registradorResposta.valor = registradorUM.valor - registradorDois.valor;
                break;
            case 3:
                System.out.println("IGUAL");
                if(registradorUM.valor == registradorDois.valor)
                    registradorResposta.valor = 1;
                else
                    registradorResposta.valor = -1;
                break;
            case 4:
                System.out.println("MAIOR");
                if(registradorUM.valor > registradorDois.valor)
                    registradorResposta.valor = 1;
                else
                    registradorResposta.valor = -1;
                break;
            case 0:
                System.out.println("NÃO PASSOU PELO PASSO DE BUSCA E INTERPRETAÇÃO!");
                break;
            default:
                break;
        }
    }
}
